﻿import { InlineKeyboard } from "grammy";
import { CALLBACK_ACTIONS } from "../constants/callback.actions.js";

export const mainKeyboard = new InlineKeyboard()
  .text("🧾 إنشاء تسعيرة", CALLBACK_ACTIONS.CREATE_QUOTE)
  .row()
  .text("📦 إدارة الطلبات", CALLBACK_ACTIONS.ORDERS)
  .row()
  .text("⚙️ الإعدادات", CALLBACK_ACTIONS.SETTINGS);
