﻿import { InlineKeyboard } from "grammy";
import { CALLBACK_ACTIONS } from "../constants/callback.actions.js";

export const quoteKeyboard = new InlineKeyboard()
  .text("🛍️ طلب من موقع واحد", CALLBACK_ACTIONS.QUOTE_SINGLE)
  .row()
  .text("🛒 طلب من عدة مواقع", CALLBACK_ACTIONS.QUOTE_MULTI)
  .row()
  .text("⬅️ رجوع", CALLBACK_ACTIONS.HOME);
