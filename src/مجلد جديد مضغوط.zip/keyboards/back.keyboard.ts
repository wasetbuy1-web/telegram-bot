import { InlineKeyboard } from "grammy";

export const backKeyboard = new InlineKeyboard()
  .text("⬅️ رجوع", "home");