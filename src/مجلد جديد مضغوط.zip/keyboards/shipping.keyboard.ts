import { InlineKeyboard } from "grammy";
import { CALLBACK_ACTIONS } from "../constants/callback.actions.js";
import type { Carrier, CarrierRate, Warehouse } from "../types/shipping.js";

export const shippingMethodKeyboard = new InlineKeyboard()
  .text("🚚 الشحن المباشر", CALLBACK_ACTIONS.SET_SHIPPING_METHOD_DIRECT)
  .row()
  .text("📦 الشحن غير المباشر", CALLBACK_ACTIONS.SET_SHIPPING_METHOD_INDIRECT)
  .row()
  .text("⬅️ رجوع", CALLBACK_ACTIONS.BACK_TO_PRODUCT_LIST)
  .row()
  .text("❌ إلغاء", CALLBACK_ACTIONS.CANCEL);

export const shippingInputKeyboard = new InlineKeyboard()
  .text("⬅️ رجوع", CALLBACK_ACTIONS.BACK_TO_SHIPPING_METHOD)
  .row()
  .text("❌ إلغاء", CALLBACK_ACTIONS.CANCEL);

export const indirectShippingKeyboard = new InlineKeyboard()
  .text("🤖 تقدير الوزن", CALLBACK_ACTIONS.ESTIMATE_WEIGHT)
  .row()
  .text("⬅️ رجوع", CALLBACK_ACTIONS.BACK_TO_SHIPPING_METHOD)
  .row()
  .text("❌ إلغاء", CALLBACK_ACTIONS.CANCEL);

export const estimateWeightKeyboard = new InlineKeyboard()
  .text("⬅️ رجوع", CALLBACK_ACTIONS.BACK_TO_INDIRECT_WEIGHT)
  .row()
  .text("❌ إلغاء", CALLBACK_ACTIONS.CANCEL);

export function warehouseKeyboard(warehouses: Warehouse[]): InlineKeyboard {
  const nameCounts = new Map<string, number>();
  for (const warehouse of warehouses) {
    nameCounts.set(warehouse.name, (nameCounts.get(warehouse.name) ?? 0) + 1);
  }

  const keyboard = new InlineKeyboard();
  for (const warehouse of warehouses) {
    const label =
      (nameCounts.get(warehouse.name) ?? 0) > 1
        ? `${warehouse.name} (#${warehouse.id})`
        : warehouse.name;
    keyboard
      .text(label, `${CALLBACK_ACTIONS.SELECT_WAREHOUSE_PREFIX}${warehouse.id}`)
      .row();
  }

  return keyboard
    .text("⬅️ رجوع", CALLBACK_ACTIONS.BACK_TO_INDIRECT_WEIGHT)
    .row()
    .text("❌ إلغاء", CALLBACK_ACTIONS.CANCEL);
}

export function priceCarrierKeyboard(rates: CarrierRate[]): InlineKeyboard {
  const keyboard = new InlineKeyboard();
  for (const rate of rates) {
    const label = `${rate.carrierName} - ${rate.price} ${rate.currency}`;
    keyboard
      .text(label, `${CALLBACK_ACTIONS.SELECT_CARRIER_PREFIX}${rate.carrierId}`)
      .row();
  }

  return keyboard
    .text("📊 عرض جميع الأسعار", CALLBACK_ACTIONS.VIEW_ALL_PRICES)
    .row()
    .text("⬅️ رجوع", CALLBACK_ACTIONS.BACK_TO_WAREHOUSE)
    .row()
    .text("❌ إلغاء", CALLBACK_ACTIONS.CANCEL);
}

export function plainCarrierKeyboard(carriers: Carrier[]): InlineKeyboard {
  const keyboard = new InlineKeyboard();
  for (const carrier of carriers) {
    keyboard
      .text(carrier.name, `${CALLBACK_ACTIONS.SELECT_CARRIER_PREFIX}${carrier.id}`)
      .row();
  }

  return keyboard
    .text("⬅️ رجوع", CALLBACK_ACTIONS.BACK_TO_SHIPPING_DETAILS)
    .row()
    .text("❌ إلغاء", CALLBACK_ACTIONS.CANCEL);
}

export const quoteSummaryKeyboard = new InlineKeyboard()
  .text("📝 إنشاء رسالة العميل", CALLBACK_ACTIONS.GENERATE_CUSTOMER_QUOTE)
  .row()
  .text("⬅️ رجوع", CALLBACK_ACTIONS.BACK_TO_SHIPPING_COMPANY)
  .row()
  .text("❌ إلغاء", CALLBACK_ACTIONS.CANCEL);

export const customerQuoteKeyboard = new InlineKeyboard()
  .text("📋 نسخ الرسالة", CALLBACK_ACTIONS.COPY_MESSAGE)
  .row()
  .text("📦 إرسال إلى الموقع", CALLBACK_ACTIONS.SEND_TO_WEBSITE)
  .row()
  .text("✏️ تعديل التسعيرة", CALLBACK_ACTIONS.EDIT_QUOTE)
  .row()
  .text("🧾 تسعيرة جديدة", CALLBACK_ACTIONS.NEW_QUOTE);
