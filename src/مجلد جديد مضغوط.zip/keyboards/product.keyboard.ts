import { InlineKeyboard } from "grammy";
import { CALLBACK_ACTIONS } from "../constants/callback.actions.js";

export function productListKeyboard(hasProducts: boolean): InlineKeyboard {
  const keyboard = new InlineKeyboard();

  if (hasProducts) {
    keyboard.text("➡️ متابعة", CALLBACK_ACTIONS.CONTINUE_QUOTE).row();
  }

  return keyboard
    .text("➕ إضافة منتج", CALLBACK_ACTIONS.ADD_PRODUCT)
    .row()
    .text("✏️ تعديل منتج", CALLBACK_ACTIONS.EDIT_PRODUCT)
    .row()
    .text("🗑 حذف منتج", CALLBACK_ACTIONS.DELETE_PRODUCT)
    .row()
    .text("⬅️ رجوع", CALLBACK_ACTIONS.BACK_TO_QUOTE_TYPE)
    .row()
    .text("❌ إلغاء", CALLBACK_ACTIONS.CANCEL);
}

export const productUrlKeyboard = new InlineKeyboard()
   .text("⬅️ رجوع", CALLBACK_ACTIONS.PRODUCT_LIST)
  .row()
  .text("❌ إلغاء", CALLBACK_ACTIONS.CANCEL);

export const productInputKeyboard = new InlineKeyboard()
  .text("⬅️ رجوع", CALLBACK_ACTIONS.PRODUCT_LIST)
  .row()
  .text("❌ إلغاء", CALLBACK_ACTIONS.CANCEL);

export const currencyKeyboard = new InlineKeyboard()
  .text("USD", CALLBACK_ACTIONS.SET_CURRENCY_USD)
  .text("SAR", CALLBACK_ACTIONS.SET_CURRENCY_SAR)
  .row()
  .text("EUR", CALLBACK_ACTIONS.SET_CURRENCY_EUR)
  .text("GBP", CALLBACK_ACTIONS.SET_CURRENCY_GBP)
  .row()
  .text("AUD", CALLBACK_ACTIONS.SET_CURRENCY_AUD)
  .text("CAD", CALLBACK_ACTIONS.SET_CURRENCY_CAD)
  .row()
  .text("SGD", CALLBACK_ACTIONS.SET_CURRENCY_SGD)
  .row()
  .text("⬅️ رجوع", CALLBACK_ACTIONS.PRODUCT_LIST)
  .row()
  .text("❌ إلغاء", CALLBACK_ACTIONS.CANCEL);

export const quantityKeyboard = new InlineKeyboard()
  .text("1", CALLBACK_ACTIONS.SELECT_QUANTITY_1)
  .text("2", CALLBACK_ACTIONS.SELECT_QUANTITY_2)
  .row()
  .text("3", CALLBACK_ACTIONS.SELECT_QUANTITY_3)
  .text("4", CALLBACK_ACTIONS.SELECT_QUANTITY_4)
  .row()
  .text("5", CALLBACK_ACTIONS.SELECT_QUANTITY_5)
  .row()
  .text("➕ إدخال رقم", CALLBACK_ACTIONS.ENTER_CUSTOM_QUANTITY)
  .row()
  .text("⬅️ رجوع", CALLBACK_ACTIONS.BACK_TO_PRODUCT_LIST)
  .row()
  .text("❌ إلغاء", CALLBACK_ACTIONS.CANCEL);

export const currencyMainKeyboard = new InlineKeyboard()
  .text("🔄 تغيير العملة", CALLBACK_ACTIONS.CHANGE_CURRENCY)
  .row()
  .text("➡️ متابعه", CALLBACK_ACTIONS.BACK_TO_PRODUCT_LIST)
  .row()
  .text("❌ إلغاء", CALLBACK_ACTIONS.CANCEL);

export const currencyConfirmedKeyboard = new InlineKeyboard()
  .text("🔄 تغيير العملة", CALLBACK_ACTIONS.CHANGE_CURRENCY)
  .row()
  .text("➡️ متابعة", CALLBACK_ACTIONS.CONTINUE_TO_QUANTITY)
  .row()
  .text("⬅️ رجوع", CALLBACK_ACTIONS.BACK_TO_PRODUCT_LIST)
  .row()
  .text("❌ إلغاء", CALLBACK_ACTIONS.CANCEL);

export const quantityMainKeyboard = new InlineKeyboard()
  .text("➕ إدخال رقم", CALLBACK_ACTIONS.SHOW_QUANTITY_SELECTOR)
  .row()
  .text("⬅️ رجوع", CALLBACK_ACTIONS.BACK_TO_PRODUCT_LIST)
  .row()
  .text("❌ إلغاء", CALLBACK_ACTIONS.CANCEL);

export const quantityConfirmedKeyboard = new InlineKeyboard()
  .text("➕ إدخال رقم", CALLBACK_ACTIONS.SHOW_QUANTITY_SELECTOR)
  .row()
  .text("➡️ متابعة", CALLBACK_ACTIONS.CONTINUE_TO_LOCAL_SHIPPING)
  .row()
  .text("⬅️ رجوع", CALLBACK_ACTIONS.BACK_TO_PRODUCT_LIST)
  .row()
  .text("❌ إلغاء", CALLBACK_ACTIONS.CANCEL);

export const shippingKeyboard = new InlineKeyboard()
  .text("مجاني", CALLBACK_ACTIONS.SET_FREE_SHIPPING)
  .row()
  .text("⬅️ رجوع", CALLBACK_ACTIONS.PRODUCT_LIST)
  .row()
  .text("❌ إلغاء", CALLBACK_ACTIONS.CANCEL);

export const categoryKeyboard = new InlineKeyboard()
  .text("تخطي", CALLBACK_ACTIONS.SKIP_CATEGORY)
  .row()
  .text("⬅️ رجوع", CALLBACK_ACTIONS.PRODUCT_LIST)
  .row()
  .text("❌ إلغاء", CALLBACK_ACTIONS.CANCEL);
