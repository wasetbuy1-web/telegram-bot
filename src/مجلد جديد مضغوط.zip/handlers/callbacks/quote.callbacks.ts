import { type Context, type SessionFlavor } from "grammy";

import { quoteKeyboard } from "../../keyboards/index.js";
import {
  productListKeyboard,
  productUrlKeyboard,
  productInputKeyboard,
  currencyKeyboard,
  quantityKeyboard,
  shippingKeyboard,
  categoryKeyboard,
  currencyMainKeyboard,
  currencyConfirmedKeyboard,
  quantityMainKeyboard,
  quantityConfirmedKeyboard,
} from "../../keyboards/product.keyboard.js";
import {
  shippingMethodKeyboard,
  shippingInputKeyboard,
  indirectShippingKeyboard,
  estimateWeightKeyboard,
  warehouseKeyboard,
  priceCarrierKeyboard,
  plainCarrierKeyboard,
  quoteSummaryKeyboard,
  customerQuoteKeyboard,
} from "../../keyboards/shipping.keyboard.js";
import {
  setQuoteType,
  beginProductEntry,
  beginShippingMethodSelection,
  setShippingMethodDirect,
  setShippingMethodIndirect,
  setShowEstimatePrompt,
  selectWarehouse,
  setShippingCompany,
  beginCustomerQuote,
  setQuoteSummaryStep,
  resetQuoteSession,
  submitProductCurrency,
  submitProductQuantity,
  submitProductLocalShipping,
  submitProductCategory,
  skipProductCategory,
} from "../../services/quote.service.js";
import { sendQuoteToWebsite } from "../../services/quote.api.service.js";
import {
  listWarehouses,
  listCarriers,
  getCarrierRatesSortedByPrice,
  getSelectedCarrierRate,
} from "../../services/shipping-pricing.service.js";
import {
  getProductPromptText,
  getProductListText,
  getShippingPromptText,
  formatAllPricesText,
} from "../../formatters/quote.formatters.js";
import { CALLBACK_ACTIONS } from "../../constants/callback.actions.js";
import type { SessionData } from "../../session/session.js";

export async function handleQuoteCallback(
  ctx: Context & SessionFlavor<SessionData>,
  action: string
): Promise<boolean> {
  if (action.startsWith(CALLBACK_ACTIONS.SELECT_WAREHOUSE_PREFIX)) {
    const warehouseId = Number(action.slice(CALLBACK_ACTIONS.SELECT_WAREHOUSE_PREFIX.length));
    const weight = ctx.session.draft.indirectWeight;

    if (!Number.isInteger(warehouseId) || weight == null) {
      await ctx.reply("خطأ داخلي: تعذر تحديد المستودع أو الوزن.");
      return true;
    }

    try {
      const warehouses = await listWarehouses();
      const warehouse = warehouses.find((item) => item.id === warehouseId);
      if (!warehouse) {
        await ctx.reply("المستودع غير موجود.");
        return true;
      }

      selectWarehouse(ctx.session, warehouse.id, warehouse.name);
      const rates = await getCarrierRatesSortedByPrice(warehouse.id, weight);

      await ctx.editMessageText(getShippingPromptText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: priceCarrierKeyboard(rates),
      });
    } catch {
      await ctx.reply("تعذر تحميل أسعار الشحن حالياً. حاول لاحقاً.");
    }
    return true;
  }

  if (action.startsWith(CALLBACK_ACTIONS.SELECT_CARRIER_PREFIX)) {
    const carrierId = Number(action.slice(CALLBACK_ACTIONS.SELECT_CARRIER_PREFIX.length));
    if (!Number.isInteger(carrierId)) {
      await ctx.reply("خطأ داخلي: شركة شحن غير صالحة.");
      return true;
    }

    try {
      const { shippingMethod, warehouseId, indirectWeight } = ctx.session.draft;

      if (shippingMethod === "indirect" && warehouseId != null && indirectWeight != null) {
        const rate = await getSelectedCarrierRate(warehouseId, carrierId, indirectWeight);
        if (!rate) {
          await ctx.reply("لا يوجد سعر متاح لهذه الشركة عند هذا الوزن.");
          return true;
        }
        setShippingCompany(ctx.session, rate.carrierName, rate.price, rate.currency);
      } else {
        const carriers = await listCarriers();
        const carrier = carriers.find((item) => item.id === carrierId);
        if (!carrier) {
          await ctx.reply("شركة الشحن غير موجودة.");
          return true;
        }
        setShippingCompany(ctx.session, carrier.name);
      }

      await ctx.editMessageText(getShippingPromptText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: quoteSummaryKeyboard,
      });
    } catch {
      await ctx.reply("تعذر اختيار شركة الشحن حالياً. حاول لاحقاً.");
    }
    return true;
  }

  switch (action) {
    case CALLBACK_ACTIONS.CREATE_QUOTE:
      await ctx.editMessageText("🧾 *إنشاء تسعيرة*\n\nاختر نوع الطلب:", {
        parse_mode: "Markdown",
        reply_markup: quoteKeyboard,
      });
      return true;

    case CALLBACK_ACTIONS.QUOTE_SINGLE:
      setQuoteType(ctx.session, "single");
      await ctx.editMessageText(getProductListText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: productListKeyboard(ctx.session.draft.products.length > 0),
      });
      return true;

    case CALLBACK_ACTIONS.QUOTE_MULTI:
      setQuoteType(ctx.session, "multi");
      await ctx.editMessageText(getProductListText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: productListKeyboard(ctx.session.draft.products.length > 0),
      });
      return true;

    case CALLBACK_ACTIONS.ADD_PRODUCT:
      beginProductEntry(ctx.session);
      await ctx.editMessageText(getProductPromptText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: productUrlKeyboard,
      });
      return true;

    case CALLBACK_ACTIONS.CHANGE_CURRENCY: {
      await ctx.editMessageText(getProductPromptText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: currencyKeyboard,
      });
      return true;
    }

    case CALLBACK_ACTIONS.SET_CURRENCY_USD:
    case CALLBACK_ACTIONS.SET_CURRENCY_SAR:
    case CALLBACK_ACTIONS.SET_CURRENCY_EUR:
    case CALLBACK_ACTIONS.SET_CURRENCY_GBP:
    case CALLBACK_ACTIONS.SET_CURRENCY_AUD:
    case CALLBACK_ACTIONS.SET_CURRENCY_CAD:
    case CALLBACK_ACTIONS.SET_CURRENCY_SGD: {
      const currency = action.replace("set_currency_", "").toUpperCase();
      const result = submitProductCurrency(ctx.session, currency);
      if (!result.success) {
        await ctx.reply(result.errorMessage);
        return true;
      }
      await ctx.editMessageText(getProductPromptText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: currencyConfirmedKeyboard,
      });
      return true;
    }

    case CALLBACK_ACTIONS.CONTINUE_TO_QUANTITY: {
      ctx.session.draft.currentStep = "quantity";
      await ctx.editMessageText(getProductPromptText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: quantityMainKeyboard,
      });
      return true;
    }

    case CALLBACK_ACTIONS.SHOW_QUANTITY_SELECTOR: {
      await ctx.editMessageText(getProductPromptText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: quantityKeyboard,
      });
      return true;
    }

    case CALLBACK_ACTIONS.ENTER_CUSTOM_QUANTITY: {
      await ctx.editMessageText(getProductPromptText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: productInputKeyboard,
      });
      return true;
    }

    case CALLBACK_ACTIONS.SELECT_QUANTITY_1:
    case CALLBACK_ACTIONS.SELECT_QUANTITY_2:
    case CALLBACK_ACTIONS.SELECT_QUANTITY_3:
    case CALLBACK_ACTIONS.SELECT_QUANTITY_4:
    case CALLBACK_ACTIONS.SELECT_QUANTITY_5: {
      const quantity = Number(action.replace("select_quantity_", ""));
      const result = submitProductQuantity(ctx.session, String(quantity));
      if (!result.success) {
        await ctx.reply(result.errorMessage);
        return true;
      }
      await ctx.editMessageText(getProductPromptText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: quantityConfirmedKeyboard,
      });
      return true;
    }

    case CALLBACK_ACTIONS.CONTINUE_TO_LOCAL_SHIPPING: {
      ctx.session.draft.currentStep = "localShipping";
      await ctx.editMessageText(getProductPromptText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: shippingKeyboard,
      });
      return true;
    }

    case CALLBACK_ACTIONS.SET_FREE_SHIPPING: {
      const result = submitProductLocalShipping(ctx.session, "مجاني");
      if (!result.success) {
        await ctx.reply(result.errorMessage);
        return true;
      }
      await ctx.editMessageText(getProductPromptText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: categoryKeyboard,
      });
      return true;
    }

    case CALLBACK_ACTIONS.SKIP_CATEGORY: {
      const result = skipProductCategory(ctx.session);
      if (!result.success) {
        await ctx.reply(result.errorMessage);
        return true;
      }
      await ctx.editMessageText(getProductListText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: productListKeyboard(ctx.session.draft.products.length > 0),
      });
      return true;
    }

    case CALLBACK_ACTIONS.BACK_TO_PRODUCT_LIST:
      ctx.session.draft.currentStep = undefined;
      await ctx.editMessageText(getProductListText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: productListKeyboard(ctx.session.draft.products.length > 0),
      });
      return true;

    case CALLBACK_ACTIONS.BACK_TO_QUOTE_TYPE:
      ctx.session.draft.currentStep = undefined;
      await ctx.editMessageText("🧾 *إنشاء تسعيرة*\n\nاختر نوع الطلب:", {
        parse_mode: "Markdown",
        reply_markup: quoteKeyboard,
      });
      return true;

    case CALLBACK_ACTIONS.CONTINUE_QUOTE: {
      if (ctx.session.draft.products.length === 0) {
        await ctx.reply("أضف منتجًا واحدًا على الأقل قبل المتابعة.");
        return true;
      }

      beginShippingMethodSelection(ctx.session);
      await ctx.editMessageText(getShippingPromptText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: shippingMethodKeyboard,
      });
      return true;
    }

    case CALLBACK_ACTIONS.SET_SHIPPING_METHOD_DIRECT: {
      const result = setShippingMethodDirect(ctx.session);
      if (!result.success) {
        await ctx.reply(result.errorMessage);
        return true;
      }

      await ctx.editMessageText(getShippingPromptText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: shippingInputKeyboard,
      });
      return true;
    }

    case CALLBACK_ACTIONS.SET_SHIPPING_METHOD_INDIRECT: {
      const result = setShippingMethodIndirect(ctx.session);
      if (!result.success) {
        await ctx.reply(result.errorMessage);
        return true;
      }

      await ctx.editMessageText(getShippingPromptText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: indirectShippingKeyboard,
      });
      return true;
    }

    case CALLBACK_ACTIONS.BACK_TO_SHIPPING_METHOD: {
      ctx.session.draft.currentStep = "shipping_method";
      await ctx.editMessageText(getShippingPromptText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: shippingMethodKeyboard,
      });
      return true;
    }

    case CALLBACK_ACTIONS.ESTIMATE_WEIGHT: {
      const result = setShowEstimatePrompt(ctx.session);
      if (!result.success) {
        await ctx.reply(result.errorMessage);
        return true;
      }

      await ctx.editMessageText(getShippingPromptText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: estimateWeightKeyboard,
      });
      return true;
    }

    case CALLBACK_ACTIONS.BACK_TO_INDIRECT_WEIGHT: {
      ctx.session.draft.currentStep = "indirect_shipping_weight";
      await ctx.editMessageText(getShippingPromptText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: indirectShippingKeyboard,
      });
      return true;
    }

    case CALLBACK_ACTIONS.BACK_TO_SHIPPING_DETAILS: {
      if (ctx.session.draft.shippingMethod === "direct") {
        ctx.session.draft.currentStep = "direct_shipping_cost";
        await ctx.editMessageText(getShippingPromptText(ctx.session), {
          parse_mode: "Markdown",
          reply_markup: shippingInputKeyboard,
        });
      } else {
        ctx.session.draft.currentStep = "indirect_shipping_weight";
        await ctx.editMessageText(getShippingPromptText(ctx.session), {
          parse_mode: "Markdown",
          reply_markup: indirectShippingKeyboard,
        });
      }
      return true;
    }

    case CALLBACK_ACTIONS.BACK_TO_WAREHOUSE: {
      ctx.session.draft.currentStep = "select_warehouse";
      try {
        const warehouses = await listWarehouses();
        await ctx.editMessageText(getShippingPromptText(ctx.session), {
          parse_mode: "Markdown",
          reply_markup: warehouseKeyboard(warehouses),
        });
      } catch {
        await ctx.reply("تعذر تحميل قائمة المستودعات حالياً. حاول لاحقاً.");
      }
      return true;
    }

    case CALLBACK_ACTIONS.BACK_TO_SHIPPING_COMPANY: {
      ctx.session.draft.currentStep = "select_shipping_company";
      try {
        const { shippingMethod, warehouseId, indirectWeight } = ctx.session.draft;
        if (shippingMethod === "indirect" && warehouseId != null && indirectWeight != null) {
          const rates = await getCarrierRatesSortedByPrice(warehouseId, indirectWeight);
          await ctx.editMessageText(getShippingPromptText(ctx.session), {
            parse_mode: "Markdown",
            reply_markup: priceCarrierKeyboard(rates),
          });
        } else {
          const carriers = await listCarriers();
          await ctx.editMessageText(getShippingPromptText(ctx.session), {
            parse_mode: "Markdown",
            reply_markup: plainCarrierKeyboard(carriers),
          });
        }
      } catch {
        await ctx.reply("تعذر تحميل شركات الشحن حالياً. حاول لاحقاً.");
      }
      return true;
    }

    case CALLBACK_ACTIONS.GENERATE_CUSTOMER_QUOTE: {
      const result = beginCustomerQuote(ctx.session);
      if (!result.success) {
        await ctx.reply(result.errorMessage);
        return true;
      }

      await ctx.editMessageText(getShippingPromptText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: customerQuoteKeyboard,
      });
      return true;
    }

    case CALLBACK_ACTIONS.COPY_MESSAGE: {
      await ctx.reply("📋 سيتم تفعيل خاصية النسخ لاحقًا.");
      return true;
    }

    case CALLBACK_ACTIONS.SEND_TO_WEBSITE: {
      const result = await sendQuoteToWebsite(ctx.session);
      if (!result.success) {
        await ctx.reply(`❌ فشل الإرسال: ${result.errorMessage}`);
        return true;
      }

      await ctx.reply("✅ تم إرسال التسعيرة إلى الموقع بنجاح. تحقق من لوحة التحكم أو اضغط للمتابعة.");
      return true;
    }

    case CALLBACK_ACTIONS.EDIT_QUOTE: {
      const result = setQuoteSummaryStep(ctx.session);
      if (!result.success) {
        await ctx.reply(result.errorMessage);
        return true;
      }

      await ctx.editMessageText(getShippingPromptText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: quoteSummaryKeyboard,
      });
      return true;
    }

    case CALLBACK_ACTIONS.NEW_QUOTE: {
      resetQuoteSession(ctx.session);
      await ctx.editMessageText("🏠 *القائمة الرئيسية*\n\nاختر أحد الخيارات:", {
        parse_mode: "Markdown",
        reply_markup: quoteKeyboard,
      });
      return true;
    }

    case CALLBACK_ACTIONS.VIEW_ALL_PRICES: {
      const { shippingMethod, warehouseId, indirectWeight } = ctx.session.draft;
      if (shippingMethod !== "indirect" || warehouseId == null || indirectWeight == null) {
        await ctx.reply("📊 عرض جميع الأسعار متاح فقط بعد اختيار الشحن غير المباشر ومستودع.");
        return true;
      }

      try {
        const rates = await getCarrierRatesSortedByPrice(warehouseId, indirectWeight);
        await ctx.reply(formatAllPricesText(rates), { parse_mode: "Markdown" });
      } catch {
        await ctx.reply("تعذر تحميل الأسعار حالياً. حاول لاحقاً.");
      }
      return true;
    }

    case CALLBACK_ACTIONS.EDIT_PRODUCT:
      ctx.session.draft.currentStep = "select_edit";
      await ctx.editMessageText(
        `${getProductListText(ctx.session)}\n\nأرسل رقم المنتج الذي تريد تعديله:`,
        {
          parse_mode: "Markdown",
          reply_markup: productListKeyboard(ctx.session.draft.products.length > 0),
        }
      );
      return true;

    case CALLBACK_ACTIONS.DELETE_PRODUCT:
      ctx.session.draft.currentStep = "select_delete";
      await ctx.editMessageText(
        `${getProductListText(ctx.session)}\n\nأرسل رقم المنتج الذي تريد حذفه:`,
        {
          parse_mode: "Markdown",
          reply_markup: productListKeyboard(ctx.session.draft.products.length > 0),
        }
      );
      return true;

    case CALLBACK_ACTIONS.PRODUCT_LIST:
      await ctx.editMessageText(getProductListText(ctx.session), {
        parse_mode: "Markdown",
        reply_markup: productListKeyboard(ctx.session.draft.products.length > 0),
      });
      return true;

    default:
      return false;
  }
}
